package com.example.nr_apasari_buton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
Button btn;
int cnt=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=(Button) findViewById(R.id.button1);
    }
    public void CountClick(View v){
        cnt++;
        btn.setText("Ati apasat de "+String.valueOf(cnt)+" ori!");
    }
}

